#!/bin/bash

# Start Ganache CLI with the specified options
ganache-cli --mnemonic "556BC093J4G034JG03K"
