import { atom } from "jotai";

export const currentProperty = atom(null);

export const currentAccount = atom(null);

export const propertiesStore = atom([]);