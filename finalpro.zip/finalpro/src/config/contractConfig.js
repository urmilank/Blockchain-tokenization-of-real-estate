const contractConfig = {
  realEstateAddress: "0x87ed01B9bD39E05821969734839E46DC36FfFDc1",
  transactionAddress: "0xb454925199e010D9E8a9Af1Ea3abf3F804e031ed",
};

export default contractConfig;
