import Homepage from "./pages/Homepage";
import TempTransaction from "./pages/TempTransaction";

export default function App() {
  return (
    <>
      <Homepage />
    </>
  );
}
